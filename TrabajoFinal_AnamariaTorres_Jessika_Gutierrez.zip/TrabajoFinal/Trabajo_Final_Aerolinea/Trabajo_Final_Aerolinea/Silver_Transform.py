
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

# ==========================================
# TRABAJO FINAL - SILVER TRANSFORM
# ==========================================

spark = SparkSession.builder.getOrCreate()

CATALOG = "aerolinea"
BRONZE = f"{CATALOG}.tf_bronze"
SILVER = f"{CATALOG}.tf_silver"

# 1. Crear esquema Silver
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SILVER}")

# 2. Leer las tablas Bronze
flights = spark.table(f"{BRONZE}.flights")
airlines = spark.table(f"{BRONZE}.airlines")
airports = spark.table(f"{BRONZE}.airports")

# 3. Preparar aerolíneas
airlines_info = airlines.select(
    "airline_id",
    "airline_name"
).dropDuplicates(["airline_id"])

# 4. Preparar aeropuertos de origen
origen = (
    airports
    .select(
        F.col("airport_id").alias("origin_airport"),
        F.col("city").alias("origin_city"),
        F.col("country").alias("origin_country")
    )
    .dropDuplicates(["origin_airport"])
)

# 5. Preparar aeropuertos de destino
destino = (
    airports
    .select(
        F.col("airport_id").alias("destination_airport"),
        F.col("city").alias("destination_city"),
        F.col("country").alias("destination_country")
    )
    .dropDuplicates(["destination_airport"])
)

# 6. Unir los datos
vuelos = (
    flights
    .join(airlines_info, "airline_id", "left")
    .join(origen, "origin_airport", "left")
    .join(destino, "destination_airport", "left")
)

# 7. Crear columnas calculadas
vuelos = (
    vuelos
    .withColumn(
        "delay_total",
        F.coalesce(F.col("departure_delay"), F.lit(0)) +
        F.coalesce(F.col("arrival_delay"), F.lit(0))
    )
    .withColumn(
        "on_time",
        F.when(
            F.coalesce(F.col("arrival_delay"), F.lit(0)) <= 15,
            1
        ).otherwise(0)
    )
    .withColumn(
        "distance_km",
        F.round(F.col("distance_miles") * 1.60934, 2)
    )
    .withColumn(
        "delay_category",
        F.when(F.col("delay_total") <= 0, "None")
         .when(F.col("delay_total") <= 15, "Short")
         .when(F.col("delay_total") <= 60, "Medium")
         .otherwise("Long")
    )
)

# 8. Guardar vuelos enriquecidos
(
    vuelos.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{SILVER}.flights_enriched")
)

# 9. Métricas por aerolínea
metricas_airlines = (
    vuelos
    .groupBy("airline_id", "airline_name")
    .agg(
        F.round(F.avg("delay_total"), 2).alias("avg_delay"),
        F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
        F.count("*").alias("total_flights"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct")
    )
)

# 10. Métricas por aeropuerto de origen
salientes = (
    vuelos
    .groupBy("origin_airport")
    .agg(
        F.count("*").alias("outgoing_flights"),
        F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct")
    )
    .withColumnRenamed("origin_airport", "airport_id")
)

# 11. Métricas por aeropuerto de destino
entrantes = (
    vuelos
    .groupBy("destination_airport")
    .agg(
        F.count("*").alias("incoming_flights"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay")
    )
    .withColumnRenamed("destination_airport", "airport_id")
)

# 12. Unir métricas de aeropuertos
metricas_aeropuertos = (
    salientes
    .join(entrantes, "airport_id", "full")
    .fillna({
        "outgoing_flights": 0,
        "incoming_flights": 0
    })
)

# 13. Guardar tablas Silver
tablas = [
    ("airline_metrics", metricas_airlines),
    ("airport_full_metrics", metricas_aeropuertos)
]

for nombre, df in tablas:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{SILVER}.{nombre}")
    )

    print(f"Tabla {nombre}: {df.count()} registros")

print(f"Vuelos Silver: {vuelos.count()}")
print("SILVER TRANSFORM FINALIZADA CORRECTAMENTE")
