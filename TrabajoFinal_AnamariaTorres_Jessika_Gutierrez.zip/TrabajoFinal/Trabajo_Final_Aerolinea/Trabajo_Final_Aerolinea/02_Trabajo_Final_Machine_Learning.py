# Databricks notebook source
# MAGIC %md
# MAGIC #Cargar y validar los datos

# COMMAND ----------


from pyspark.sql import functions as F

# Cargar los vuelos procesados en Silver
vuelos = spark.table("aerolinea.tf_silver.flights_enriched")

print("Total de vuelos:", vuelos.count())

# Revisar columnas y tipos de datos
print("\nESQUEMA DE LOS DATOS:")
vuelos.printSchema()

# Mostrar los primeros registros
print("\nMUESTRA DE LOS DATOS:")
display(vuelos.limit(10))

# Comprobar que exista la variable objetivo
if "arrival_delay" in vuelos.columns:
    print("\nVariable objetivo encontrada: arrival_delay")
else:
    print("\nATENCIÓN: No se encontró arrival_delay")
    print("Columnas disponibles:", vuelos.columns)


# COMMAND ----------

# MAGIC %md
# MAGIC #Preparar los datos para Machine Learning

# COMMAND ----------


from pyspark.sql import functions as F

# Seleccionar las columnas necesarias
datos_ml = vuelos.select(
    "flight_id",
    "flight_date",
    "airline_id",
    "origin_airport",
    "destination_airport",
    "departure_delay",
    "distance_miles",
    "arrival_delay"
)

# Eliminar registros sin información necesaria
datos_ml = datos_ml.dropna(subset=[
    "departure_delay",
    "distance_miles",
    "arrival_delay",
    "airline_id",
    "origin_airport",
    "destination_airport"
])

# Crear variables temporales
datos_ml = (
    datos_ml
    .withColumn("month", F.month("flight_date"))
    .withColumn("day_of_week", F.dayofweek("flight_date"))
)

# Guardar los datos preparados en Gold
datos_ml.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("aerolinea.tf_gold.ml_flights")

print("DATOS PREPARADOS CORRECTAMENTE")
print("Total de registros:", datos_ml.count())

display(datos_ml.limit(10))


# COMMAND ----------

# MAGIC %md
# MAGIC #Dividir los datos en entrenamiento y evaluación

# COMMAND ----------


from pyspark.ml.feature import VectorAssembler
from pyspark.sql import functions as F

# Cargar los datos preparados desde Gold
datos = spark.table("aerolinea.tf_gold.ml_flights")

# Seleccionar variables predictoras
variables = [
    "departure_delay",
    "distance_miles",
    "month",
    "day_of_week"
]

# Preparar las variables para Spark ML
assembler = VectorAssembler(
    inputCols=variables,
    outputCol="features",
    handleInvalid="skip"
)

datos_modelo = assembler.transform(datos).select(
    "flight_id",
    "features",
    F.col("arrival_delay").cast("double").alias("label")
)

# Dividir en entrenamiento (80 %) y evaluacion (20 %)
entrenamiento, evaluacion = datos_modelo.randomSplit(
    [0.8, 0.2],
    seed=42
)

# Mostrar resultados
print("DATOS DIVIDIDOS CORRECTAMENTE")
print("Registros de entrenamiento:", entrenamiento.count())
print("Registros de evaluacion:", evaluacion.count())

display(entrenamiento.limit(5))


# COMMAND ----------

# MAGIC %md
# MAGIC #Entrenar los dos modelos y calcular MAE y RMSE

# COMMAND ----------


from pyspark.ml.regression import DecisionTreeRegressor
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.sql import functions as F


# 1. Modelo de referencia: promedio del entrenamiento
promedio = entrenamiento.agg(
    F.avg("label").alias("promedio")
).first()["promedio"]

pred_base = evaluacion.withColumn(
    "prediction", F.lit(float(promedio))
)

# 2. Modelo de arbol de regresion
arbol = DecisionTreeRegressor(
    featuresCol="features",
    labelCol="label",
    predictionCol="prediction",
    maxDepth=5,
    seed=42
)

modelo_arbol = arbol.fit(entrenamiento)
pred_arbol = modelo_arbol.transform(evaluacion)

# 3. Evaluar ambos modelos
evaluador_mae = RegressionEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="mae"
)

evaluador_rmse = RegressionEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="rmse"
)

resultados = [
    (
        "Promedio",
        evaluador_mae.evaluate(pred_base),
        evaluador_rmse.evaluate(pred_base)
    ),
    (
        "Arbol de regresion",
        evaluador_mae.evaluate(pred_arbol),
        evaluador_rmse.evaluate(pred_arbol)
    )
]

metricas = spark.createDataFrame(
    resultados,
    ["modelo", "MAE", "RMSE"]
)

print("MODELOS ENTRENADOS CORRECTAMENTE")
print("Retraso promedio de referencia:", round(promedio, 2))

display(metricas)


# COMMAND ----------

# MAGIC %md
# MAGIC #Visualizar las predicciones

# COMMAND ----------


import matplotlib.pyplot as plt

# Obtener una muestra de las predicciones
base = pred_base.select(
    "flight_id", "label", "prediction"
).withColumnRenamed("prediction", "pred_promedio")

arbol_resultados = pred_arbol.select(
    "flight_id", "prediction"
).withColumnRenamed("prediction", "pred_arbol")

comparacion = base.join(
    arbol_resultados, on="flight_id", how="inner"
)

muestra = comparacion.limit(500).toPandas()

# Crear las graficas
fig, ejes = plt.subplots(1, 2, figsize=(13, 5))

# Grafica 1: valores reales frente a predicciones
ejes[0].scatter(
    muestra["label"],
    muestra["pred_promedio"],
    label="Promedio",
    alpha=0.5
)

ejes[0].scatter(
    muestra["label"],
    muestra["pred_arbol"],
    label="Arbol",
    alpha=0.5
)

limite_min = min(
    muestra["label"].min(),
    muestra["pred_promedio"].min(),
    muestra["pred_arbol"].min()
)

limite_max = max(
    muestra["label"].max(),
    muestra["pred_promedio"].max(),
    muestra["pred_arbol"].max()
)

ejes[0].plot(
    [limite_min, limite_max],
    [limite_min, limite_max],
    "--",
    color="gray",
    label="Prediccion perfecta"
)

ejes[0].set(
    xlabel="Retraso real (minutos)",
    ylabel="Retraso estimado (minutos)",
    title="Predicciones frente a valores reales"
)
ejes[0].legend()

# Grafica 2: comparacion del MAE
metricas_pd = metricas.toPandas()

ejes[1].bar(
    metricas_pd["modelo"],
    metricas_pd["MAE"]
)

ejes[1].set(
    ylabel="MAE (minutos)",
    title="Comparacion de errores"
)

plt.tight_layout()
display(fig)
plt.close(fig)

print("VISUALIZACION COMPLETADA CORRECTAMENTE")


# COMMAND ----------

# MAGIC %md
# MAGIC #Guardar las predicciones y las métricas

# COMMAND ----------


from pyspark.sql import functions as F


# Guardar predicciones de ambos modelos
predicciones = (
    pred_base.select(
        "flight_id",
        F.col("label").alias("retraso_real"),
        F.col("prediction").alias("pred_promedio")
    )
    .join(
        pred_arbol.select(
            "flight_id",
            F.col("prediction").alias("pred_arbol")
        ),
        on="flight_id",
        how="inner"
    )
)

predicciones.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("aerolinea.tf_gold.ml_predicciones")

# Guardar métricas de evaluación
metricas.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("aerolinea.tf_gold.ml_metricas")

print("PREDICCIONES Y METRICAS GUARDADAS CORRECTAMENTE")

print("Total de predicciones:", predicciones.count())

print("\nMETRICAS GUARDADAS:")
display(spark.table("aerolinea.tf_gold.ml_metricas"))


# COMMAND ----------

# MAGIC %md
# MAGIC #Registrar el modelo y la ejecución en MLflow

# COMMAND ----------

import os
import mlflow
import mlflow.spark

os.environ["MLFLOW_DFS_TMP"] = "/Volumes/aerolinea/trabajo_final/landing"

with mlflow.start_run(run_name="Arbol_Regresion_Vuelos"):
    mlflow.log_metric("MAE", 8.25663387441488)
    mlflow.log_metric("RMSE", 10.3140743438431)

    mlflow.log_param("modelo", "DecisionTreeRegressor")
    mlflow.log_param("registros_entrenamiento", 39161)
    mlflow.log_param("registros_evaluacion", 9845)

    mlflow.spark.log_model(
        spark_model=modelo_arbol,
        artifact_path="modelo_arbol",
        dfs_tmpdir="/Volumes/aerolinea/trabajo_final/landing"
    )

print("MODELO REGISTRADO CORRECTAMENTE EN MLFLOW")