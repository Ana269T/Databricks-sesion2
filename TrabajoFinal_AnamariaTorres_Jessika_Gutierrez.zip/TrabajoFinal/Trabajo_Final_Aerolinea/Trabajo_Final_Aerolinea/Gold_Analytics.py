
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# ==========================================
# TRABAJO FINAL - GOLD ANALYTICS
# ==========================================

spark = SparkSession.builder.getOrCreate()

CATALOG = "aerolinea"
SILVER = f"{CATALOG}.tf_silver"
GOLD = f"{CATALOG}.tf_gold"

# 1. Crear esquema Gold
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {GOLD}")

# 2. Leer los datos de Silver
vuelos = spark.table(f"{SILVER}.flights_enriched")

# 3. Agregar año y mes
vuelos = (
    vuelos
    .withColumn("anio", F.year("flight_date"))
    .withColumn("mes", F.month("flight_date"))
)

# 4. Retrasos por aerolínea, aeropuerto y mes
retrasos_mensuales = (
    vuelos
    .groupBy(
        "airline_id",
        "airline_name",
        "origin_airport",
        "anio",
        "mes"
    )
    .agg(
        F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
        F.round(F.avg("delay_total"), 2).alias("avg_total_delay"),
        F.count("*").alias("total_flights")
    )
)

# 5. Puntualidad de aeropuertos
puntualidad_aeropuertos = (
    vuelos
    .groupBy("origin_airport", "origin_city")
    .agg(
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.round(F.avg("departure_delay"), 2).alias("avg_delay"),
        F.count("*").alias("total_flights")
    )
)

# 6. Ranking de aeropuertos
ventana = Window.orderBy(
    F.col("on_time_pct").desc(),
    F.col("avg_delay").asc()
)

ranking_puntualidad = (
    puntualidad_aeropuertos
    .withColumn("airport_rank", F.dense_rank().over(ventana))
)

# 7. KPI de puntualidad por aerolínea
kpi_aerolineas = (
    vuelos
    .groupBy("airline_id", "airline_name")
    .agg(
        F.count("*").alias("total_flights"),
        F.sum("on_time").alias("on_time_flights"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay")
    )
)

# 8. Guardar las tablas Gold
tablas = [
    ("retrasos_mensuales", retrasos_mensuales),
    ("ranking_puntualidad", ranking_puntualidad),
    ("kpi_aerolineas", kpi_aerolineas)
]

for nombre, df in tablas:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{GOLD}.{nombre}")
    )

    print(f"Tabla {nombre}: {df.count()} registros")

# 9. Optimizar las tablas Delta
for nombre, _ in tablas:
    spark.sql(f"OPTIMIZE {GOLD}.{nombre}")
    print(f"Optimización completada: {nombre}")

# 10. Validar los resultados
print("\nRANKING DE AEROPUERTOS")
display(
    spark.table(f"{GOLD}.ranking_puntualidad")
    .orderBy("airport_rank")
)

print("\nKPI POR AEROLÍNEA")
display(
    spark.table(f"{GOLD}.kpi_aerolineas")
    .orderBy(F.col("on_time_pct").desc())
)

print("\nGOLD ANALYTICS FINALIZADA CORRECTAMENTE")
