# Databricks notebook source
ruta = "/Volumes/aerolinea/trabajo_final/landing/"

for archivo in ["airlines.csv", "airports.csv", "flights.csv"]:
    df = (
        spark.read
        .option("header", True)
        .option("inferSchema", True)
        .csv(ruta + archivo)
    )

    print(f"\nArchivo: {archivo}")
    print(f"Registros: {df.count()}")
    df.printSchema()
    display(df.limit(5))

# COMMAND ----------


from pyspark.sql import functions as F

# ==========================================
# APARTADO 1: INGESTIÓN Y LIMPIEZA - BRONZE
# ==========================================

# 1. Ruta de los archivos CSV
BASE_PATH = "/Volumes/aerolinea/trabajo_final/landing/"

# 2. Crear esquema Bronze
spark.sql("CREATE SCHEMA IF NOT EXISTS aerolinea.tf_bronze")

# 3. Leer los archivos CSV
flights = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "flights.csv")
)

airlines = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "airlines.csv")
)

airports = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "airports.csv")
)

# 4. Limpiar y transformar los vuelos
flights_bronze = (
    flights
    .withColumn("flight_date", F.to_date(F.col("flight_date")))
    .withColumn(
        "departure_delay",
        F.col("departure_delay").cast("double").cast("int")
    )
    .withColumn(
        "arrival_delay",
        F.col("arrival_delay").cast("double").cast("int")
    )
    .withColumn(
        "distance_miles",
        F.col("distance_miles").cast("double")
    )
    .dropna(subset=[
        "flight_id",
        "airline_id",
        "origin_airport"
    ])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 5. Preparar aerolíneas
airlines_bronze = (
    airlines
    .dropna(subset=["airline_id"])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 6. Preparar aeropuertos
airports_bronze = (
    airports
    .dropna(subset=["airport_id"])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 7. Guardar las tablas en Delta Lake
tablas = [
    ("flights", flights_bronze),
    ("airlines", airlines_bronze),
    ("airports", airports_bronze)
]

for nombre, df in tablas:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"aerolinea.tf_bronze.{nombre}")
    )

    print(f"Tabla {nombre} guardada correctamente")
    print(f"Total de registros: {df.count()}")

# 8. Validar las tablas creadas
print("\n========== VALIDACIÓN BRONZE ==========")

for nombre in ["flights", "airlines", "airports"]:
    tabla = spark.table(f"aerolinea.tf_bronze.{nombre}")

    print(f"\nTabla: {nombre}")
    print(f"Registros: {tabla.count()}")
    tabla.printSchema()

print("\nCAPA BRONZE FINALIZADA CORRECTAMENTE")


# COMMAND ----------

# MAGIC %md
# MAGIC #Transformaciones y modelado en Silver

# COMMAND ----------


from pyspark.sql import functions as F

# ==========================================
# APARTADO 2: TRANSFORMACIONES - SILVER
# ==========================================

# 1. Crear esquema Silver
spark.sql("CREATE SCHEMA IF NOT EXISTS aerolinea.tf_silver")

# 2. Leer tablas Bronze
flights = spark.table("aerolinea.tf_bronze.flights")
airlines = spark.table("aerolinea.tf_bronze.airlines")
airports = spark.table("aerolinea.tf_bronze.airports")

# 3. Preparar información de aerolíneas
airlines_info = airlines.select(
    "airline_id",
    "airline_name"
)

# 4. Preparar aeropuertos de origen
origen = airports.select(
    F.col("airport_id").alias("origin_airport"),
    F.col("city").alias("origin_city"),
    F.col("country").alias("origin_country")
)

# 5. Preparar aeropuertos de destino
destino = airports.select(
    F.col("airport_id").alias("destination_airport"),
    F.col("city").alias("destination_city"),
    F.col("country").alias("destination_country")
)

# 6. Unir los datos
vuelos_silver = (
    flights
    .join(airlines_info, "airline_id", "left")
    .join(origen, "origin_airport", "left")
    .join(destino, "destination_airport", "left")
)

# 7. Crear columnas calculadas
vuelos_silver = (
    vuelos_silver
    .withColumn(
        "delay_total",
        F.coalesce(F.col("departure_delay"), F.lit(0)) +
        F.coalesce(F.col("arrival_delay"), F.lit(0))
    )
    .withColumn(
        "on_time",
        F.when(F.coalesce(F.col("arrival_delay"), F.lit(0)) <= 15, 1)
         .otherwise(0)
    )
    .withColumn(
        "distance_km",
        F.round(F.col("distance_miles") * 1.60934, 2)
    )
    .withColumn(
        "delay_category",
        F.when(F.col("delay_total") <= 0, "None")
         .when(F.col("delay_total") <= 15, "Short")
         .when(F.col("delay_total") <= 60, "Medium")
         .otherwise("Long")
    )
)

# 8. Validar registros
print("Total de vuelos Silver:", vuelos_silver.count())

# 9. Guardar tabla Silver
(
    vuelos_silver.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable("aerolinea.tf_silver.flights_enriched")
)

# 10. Métricas por aerolínea
metricas_airlines = (
    vuelos_silver
    .groupBy("airline_id", "airline_name")
    .agg(
        F.round(F.avg("delay_total"), 2).alias("avg_delay"),
        F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
        F.count("*").alias("total_flights"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct")
    )
)

# 11. Métricas por aeropuerto de origen
metricas_airports = (
    vuelos_silver
    .groupBy("origin_airport", "origin_city")
    .agg(
        F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.count("*").alias("outgoing_flights")
    )
)

# 12. Guardar métricas Silver
(
    metricas_airlines.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable("aerolinea.tf_silver.airline_metrics")
)

(
    metricas_airports.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable("aerolinea.tf_silver.airport_metrics")
)

# 13. Mostrar resultados
print("\nMÉTRICAS POR AEROLÍNEA")
display(metricas_airlines)

print("\nMÉTRICAS POR AEROPUERTO")
display(metricas_airports)

print("\nCAPA SILVER FINALIZADA CORRECTAMENTE")


# COMMAND ----------

# MAGIC %md
# MAGIC #Completar las métricas de Silver

# COMMAND ----------


from pyspark.sql import functions as F

# ==========================================
# COMPLEMENTO APARTADO 2 - SILVER
# ==========================================

# Leer la tabla Silver ya creada
vuelos = spark.table("aerolinea.tf_silver.flights_enriched")

# 1. Métricas por aeropuerto de origen
salientes = (
    vuelos
    .groupBy("origin_airport")
    .agg(
        F.count("*").alias("outgoing_flights"),
        F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct")
    )
    .withColumnRenamed("origin_airport", "airport_id")
)

# 2. Métricas por aeropuerto de destino
entrantes = (
    vuelos
    .groupBy("destination_airport")
    .agg(
        F.count("*").alias("incoming_flights"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay")
    )
    .withColumnRenamed("destination_airport", "airport_id")
)

# 3. Unir las métricas
metricas_aeropuertos = (
    salientes
    .join(entrantes, "airport_id", "full")
    .fillna({
        "outgoing_flights": 0,
        "incoming_flights": 0
    })
)

# 4. Guardar resultados en Delta Lake
(
    metricas_aeropuertos.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable("aerolinea.tf_silver.airport_full_metrics")
)

# 5. Mostrar resultados
display(metricas_aeropuertos.orderBy("airport_id"))

print("MÉTRICAS DE AEROPUERTOS COMPLETADAS CORRECTAMENTE")


# COMMAND ----------

# MAGIC %md
# MAGIC #Análisis avanzado y métricas

# COMMAND ----------


from pyspark.sql import functions as F
from pyspark.sql.window import Window

# ==========================================
# APARTADO 3: ANÁLISIS AVANZADO Y MÉTRICAS
# ==========================================

spark.sql("CREATE SCHEMA IF NOT EXISTS aerolinea.tf_analisis")

# 1. Leer los vuelos enriquecidos de Silver
vuelos = spark.table("aerolinea.tf_silver.flights_enriched")

# 2. Agregar variables temporales
vuelos = (
    vuelos
    .withColumn("mes", F.month("flight_date"))
    .withColumn("dia_semana", F.dayofweek("flight_date"))
    .withColumn("trimestre", F.quarter("flight_date"))
)

# 3. Análisis de retrasos por mes, día y trimestre
retrasos_temporales = (
    vuelos
    .groupBy("mes", "dia_semana", "trimestre")
    .agg(
        F.round(F.avg("delay_total"), 2).alias("avg_delay"),
        F.count("*").alias("total_flights")
    )
)

# 4. Ranking de vuelos por retraso dentro de cada aerolínea
ventana_row = Window.partitionBy("airline_id").orderBy(
    F.col("delay_total").desc(),
    F.col("flight_id").asc()
)

ventana_dense = Window.partitionBy("airline_id").orderBy(
    F.col("delay_total").desc()
)

ranking_vuelos = (
    vuelos
    .withColumn("row_number", F.row_number().over(ventana_row))
    .withColumn("dense_rank", F.dense_rank().over(ventana_dense))
)

top_5_vuelos = ranking_vuelos.filter(F.col("row_number") <= 5)

# 5. Ranking de aeropuertos por retraso promedio
ranking_aeropuertos = (
    vuelos
    .groupBy("origin_airport")
    .agg(
        F.round(F.avg("departure_delay"), 2).alias("avg_delay")
    )
)

ventana_airport = Window.orderBy(F.col("avg_delay").asc())

ranking_aeropuertos = ranking_aeropuertos.withColumn(
    "airport_rank",
    F.dense_rank().over(ventana_airport)
)

# 6. Métricas por aerolínea y mes
metricas_airline_mes = (
    vuelos
    .groupBy("airline_id", "airline_name", "mes")
    .agg(
        F.round(F.avg("delay_total"), 2).alias("avg_delay"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.count("*").alias("total_flights")
    )
)

# 7. Guardar resultados en Delta Lake
tablas = [
    ("retrasos_temporales", retrasos_temporales),
    ("top_5_vuelos", top_5_vuelos),
    ("ranking_aeropuertos", ranking_aeropuertos),
    ("metricas_airline_mes", metricas_airline_mes)
]

for nombre, df in tablas:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"aerolinea.tf_analisis.{nombre}")
    )
    print(f"Tabla {nombre} guardada: {df.count()} registros")

# 8. Mostrar resultados
print("\nTOP 5 VUELOS CON MAYOR RETRASO POR AEROLÍNEA")
display(
    top_5_vuelos
    .select(
        "airline_id", "flight_id", "delay_total",
        "row_number", "dense_rank"
    )
    .orderBy("airline_id", "row_number")
)

print("\nRANKING DE AEROPUERTOS")
display(ranking_aeropuertos.orderBy("airport_rank"))

print("\nMÉTRICAS POR AEROLÍNEA Y MES")
display(metricas_airline_mes.orderBy("airline_id", "mes"))

print("\nAPARTADO 3 FINALIZADO CORRECTAMENTE")


# COMMAND ----------

# MAGIC %md
# MAGIC #Crear la capa Gold

# COMMAND ----------


from pyspark.sql import functions as F
from pyspark.sql.window import Window

# ==========================================
# APARTADO 4: CAPA GOLD Y ANÁLISIS DE NEGOCIO
# ==========================================

# 1. Crear esquema Gold
spark.sql("CREATE SCHEMA IF NOT EXISTS aerolinea.tf_gold")

# 2. Leer datos Silver
vuelos = spark.table("aerolinea.tf_silver.flights_enriched")

# 3. Añadir el mes y año para las métricas
vuelos = (
    vuelos
    .withColumn("anio", F.year("flight_date"))
    .withColumn("mes", F.month("flight_date"))
)

# 4. Retraso promedio por aerolínea, aeropuerto y mes
retrasos_mensuales = (
    vuelos
    .groupBy(
        "airline_id",
        "airline_name",
        "origin_airport",
        "anio",
        "mes"
    )
    .agg(
        F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
        F.round(F.avg("delay_total"), 2).alias("avg_total_delay"),
        F.count("*").alias("total_flights")
    )
)

# 5. Ranking de aeropuertos más puntuales
puntualidad_aeropuertos = (
    vuelos
    .groupBy("origin_airport", "origin_city")
    .agg(
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.round(F.avg("departure_delay"), 2).alias("avg_delay"),
        F.count("*").alias("total_flights")
    )
)

ventana_ranking = Window.orderBy(
    F.col("on_time_pct").desc(),
    F.col("avg_delay").asc()
)

ranking_puntualidad = puntualidad_aeropuertos.withColumn(
    "airport_rank",
    F.dense_rank().over(ventana_ranking)
)

# 6. KPI de puntualidad por aerolínea
kpi_aerolineas = (
    vuelos
    .groupBy("airline_id", "airline_name")
    .agg(
        F.count("*").alias("total_flights"),
        F.sum("on_time").alias("on_time_flights"),
        F.round(F.avg("on_time") * 100, 2).alias("on_time_pct"),
        F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay")
    )
)

# 7. Guardar las tablas Gold en Delta Lake
tablas_gold = [
    ("retrasos_mensuales", retrasos_mensuales),
    ("ranking_puntualidad", ranking_puntualidad),
    ("kpi_aerolineas", kpi_aerolineas)
]

for nombre, df in tablas_gold:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"aerolinea.tf_gold.{nombre}")
    )

    print(f"Tabla Gold creada: {nombre} - {df.count()} registros")

# 8. Optimizar las tablas Delta
for nombre, _ in tablas_gold:
    spark.sql(f"OPTIMIZE aerolinea.tf_gold.{nombre}")
    print(f"Tabla optimizada: {nombre}")

# 9. Mostrar los resultados
print("\nRETRASOS MENSUALES")
display(retrasos_mensuales.orderBy("airline_id", "anio", "mes"))

print("\nRANKING DE AEROPUERTOS MÁS PUNTUALES")
display(ranking_puntualidad.orderBy("airport_rank"))

print("\nKPI DE PUNTUALIDAD POR AEROLÍNEA")
display(kpi_aerolineas.orderBy(F.col("on_time_pct").desc()))

print("\nCAPA GOLD FINALIZADA CORRECTAMENTE")
