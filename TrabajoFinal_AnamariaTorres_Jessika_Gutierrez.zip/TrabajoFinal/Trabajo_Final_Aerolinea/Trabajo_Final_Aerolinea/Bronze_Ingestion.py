
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

# ==========================================
# TRABAJO FINAL - BRONZE INGESTION
# ==========================================

spark = SparkSession.builder.getOrCreate()

CATALOG = "aerolinea"
SCHEMA = "tf_bronze"
BASE_PATH = "/Volumes/aerolinea/trabajo_final/landing/"

# 1. Crear esquema Bronze
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")

# 2. Leer los archivos CSV
flights = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "flights.csv")
)

airlines = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "airlines.csv")
)

airports = (
    spark.read
    .option("header", True)
    .csv(BASE_PATH + "airports.csv")
)

# 3. Transformar los datos de vuelos
flights_bronze = (
    flights
    .withColumn("flight_date", F.to_date("flight_date"))
    .withColumn(
        "departure_delay",
        F.col("departure_delay").cast("double").cast("int")
    )
    .withColumn(
        "arrival_delay",
        F.col("arrival_delay").cast("double").cast("int")
    )
    .withColumn(
        "distance_miles",
        F.col("distance_miles").cast("double")
    )
    .dropna(subset=[
        "flight_id",
        "airline_id",
        "origin_airport"
    ])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 4. Preparar aerolíneas
airlines_bronze = (
    airlines
    .dropna(subset=["airline_id"])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 5. Preparar aeropuertos
airports_bronze = (
    airports
    .dropna(subset=["airport_id"])
    .withColumn("ingest_timestamp", F.current_timestamp())
)

# 6. Guardar las tablas en Delta Lake
tablas = [
    ("flights", flights_bronze),
    ("airlines", airlines_bronze),
    ("airports", airports_bronze)
]

for nombre, df in tablas:
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{CATALOG}.{SCHEMA}.{nombre}")
    )

    print(f"Tabla {nombre}: {df.count()} registros")

print("BRONZE INGESTION FINALIZADA CORRECTAMENTE")
